#include <iostream>

int main()
{
	std::cout << "Hello World!\n";
	std::cout << "How are you?\n";

	return 0;
}
