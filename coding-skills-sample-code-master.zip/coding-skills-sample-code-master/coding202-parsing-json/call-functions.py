print ("I'm not a function")

def my_function():
        print("Hey I'm a function!")
        

def brett(val):
    for i in range(val):
        print("I'm a function with args!")
    
    
    
my_function()
brett(5)