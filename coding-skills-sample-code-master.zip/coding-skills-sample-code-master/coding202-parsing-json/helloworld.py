print ("Helloworld!")

num = 1

if num < 1:
    print ("I'm less than 1!")
    print ("Goodbye Cruel World!")
