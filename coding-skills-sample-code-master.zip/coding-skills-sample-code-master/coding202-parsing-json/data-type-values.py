my_list=[5,'joe']
print (my_list[1])

my_tuple=('brett','Cisco',9)
print (my_tuple[1])


my_dict={"red":1,"green":2}
print(my_dict["green"])