# 0 Type anything (Temp)

# 1 Import our required libraries: Request, urlopen, json

# 2 Specify our URI

# 3 Setup a connection Request

# 4 Add the appropriate headers to our HTTP request

# 5 Do the actual request and collect the response with urlopen (Also do # 15)

# 6 Store the Response string

# 7 Load the JSON Object

# 8 Print the JSON Object (Temp)

# 9 Extract the floors from Building\Floor

# 10 Loop through the Floors

# 11 Print the Floor (Temp)

# 12 Get the APs from the Floor

# 13 Print the APs

# 14 Loop through the APs printing them out

# 15 Close the response
