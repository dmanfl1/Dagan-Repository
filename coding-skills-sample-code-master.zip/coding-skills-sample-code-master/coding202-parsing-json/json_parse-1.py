food={"vegetables":["carrots","kale","cucumber","tomato"]}

cars={"sports":{"Porsche":"Volkswagen","Viper":"Dodge","Corvette":"Chevy"}}



#Assignment
dessert={"iceCream":["Rocky-Road","strawberry","Pistachio-Cashew","Pecan-Praline"]}


superhero={"Super":("Batman","Green-Hornet", "Wonder-Woman","Superman")}


soup={"soup":{"tomato":"healthy","onion":"bleh!","vegetable":"goodForYou"}}

        
network={"Network":{"router":{"ipaddress":"192.168.1.21","mac_address":"08:56:27:6f:2b:9c"}}}


                       